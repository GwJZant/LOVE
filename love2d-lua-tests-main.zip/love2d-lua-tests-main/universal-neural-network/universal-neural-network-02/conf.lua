function love.conf(t)
    t.window.title = "XOR, universal-neural-network v.1-02 (Löve v.11.3)"
end
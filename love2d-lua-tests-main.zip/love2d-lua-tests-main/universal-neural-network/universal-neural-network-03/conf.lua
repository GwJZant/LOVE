function love.conf(t)
    t.window.title = "graph, universal-neural-network v.1-03 (Löve v.11.3)"
	t.window.usedpiscale = false
end
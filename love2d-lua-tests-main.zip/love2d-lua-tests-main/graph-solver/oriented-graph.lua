-- connections from and to nodes, weights/costs
-- for example from 1 to 9:
return
{
	{1, 2, 10}, -- from, to, weight
	{1, 4, 8},
	{1, 3, 6},
	{2, 4, 5},
	{2, 5, 13},
	{2, 7, 11},
	{3, 5, 3},
	{4, 3, 2},
	{4, 6, 7},
	{4, 7, 12},
	{5, 6, 9},
	{5, 9, 12},
	{6, 9, 10},
	{6, 8, 8},
	{7, 8, 6},
	{7, 9, 16},
	{8, 9, 15},
}

-- 1-3-5-9 -- costs 21
-- settings.lua
-- all comments in code are in english and lowercase

local Settings = {}

Settings.cameraSpeed = 500 -- pixels per second
Settings.cameraScale = 1   -- default zoom scale

return Settings

function love.conf(t)
	t.window.title = "Zoom to Mouse"
    t.version = "11.3"
end


local MarchingSquares = {}
MarchingSquares.getContours= function(data, levels) 
	local lines_handler = {}
	
	
	return 
end


return MarchingSquares
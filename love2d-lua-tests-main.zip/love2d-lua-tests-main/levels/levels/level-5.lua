local level = {}

for i = 1, 10 do
	table.insert (level, math.random())
end

return level
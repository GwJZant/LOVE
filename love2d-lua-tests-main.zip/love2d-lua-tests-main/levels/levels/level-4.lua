local level = {}

for i = 1, 8 do
	table.insert (level, math.random())
end

return level